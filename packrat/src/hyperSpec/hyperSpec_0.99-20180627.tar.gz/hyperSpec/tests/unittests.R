library ("hyperSpec")
hy.unittest ()

library (testthat)
test_check("hyperSpec")

