.onLoad <- function(lib, pkg)
   packageStartupMessage("sROC 0.1-2 loaded")
